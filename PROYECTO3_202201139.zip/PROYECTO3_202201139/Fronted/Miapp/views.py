from django.shortcuts import render
import requests
from .forms import FileForm
from django.http import HttpResponse
import webbrowser


API = 'http://localhost:5000'

def index(request):
    return render(request, 'index.html')

def cargarArchivo(request):
    return render(request, 'cargarArchivo.html')

def cargarArchivo2(request):
    return render(request, 'cargarArchivo2.html')

def ConsultaEstadoC(request):
    return render(request, 'ConsultaEstadoC.html')
def graficar(request):
    return render(request, 'graficar.html')

def ayuda(request):
    return render(request, 'ayuda.html')


def cargarArchivoXML(request):
    context = {
        'content': None
    }

    if request.method == 'POST':
        form = FileForm(request.POST, request.FILES)
        if form.is_valid():
            txt = form.cleaned_data['file'].read()

            response = requests.post(f'{API}/cargarTransaccion', data=txt)
            if response.status_code == 200:
                context['content'] = response.text
                return render(request, 'cargarArchivo.html', context)
            elif response.status_code == 400:
                context['content'] = response.text
                return render(request, 'cargarArchivo.html', context)
            else:
                 return render(request, 'cargarArchivo.html')
    form = FileForm()
    return render(request, 'cargarArchivo.html', {'form': form})



def cargarArchivoXMLConfig(request):
    context = {
        'content': None
    }

    if request.method == 'POST':
        form = FileForm(request.POST, request.FILES)
        if form.is_valid():
            txt = form.cleaned_data['file'].read()

            response = requests.post(f'{API}/cargarConfiguracion', data=txt)

            if response.status_code == 200:
                context['content'] = response.text
                return render(request, 'cargarArchivo2.html', context)
            elif response.status_code == 400:
                context['content'] = response.text
                return render(request, 'cargarArchivo2.html', context)
            
        return render(request, 'cargarArchivo2.html')   
    form = FileForm()
    return render(request, 'cargarArchivo2.html', {'form': form})




def limpiarDatosConfig(request):
    try:
        response = requests.delete(f'{API}/limpiarDatosConfig')
        
        # Verificar el estado de la respuesta
        if response.status_code == 200:            
            return render(request, 'cargarArchivo2.html', {'content': response.text})
        else:
            return render(request, 'cargarArchivo2.html')
        
    except Exception as e:
        return HttpResponse('Error: {}'.format(str(e)), status=500)

def limpiarDatosTransacciones(request):
    try:
        response = requests.delete(f'{API}/limpiarDatosTransacciones')
        
        # Verificar el estado de la respuesta
        if response.status_code == 200:            
            return render(request, 'cargarArchivo.html', {'content': response.text})
        else:
            return render(request, 'cargarArchivo.html')
        
    except Exception as e:
        return HttpResponse('Error: {}'.format(str(e)), status=500)

def consultarEstadoCliente(request):

    try:
        if request.method == 'GET':
            
            nit = request.GET['nit'] # Obtener el NIT del cliente del formulario
            print(nit)

            response = requests.get(f'{API}/consultarEstadoCliente/{nit}') # Hacer la petición al API

            if not nit: 
                return render(request, 'ConsultaEstadoC.html', {'content': 'Introduce un NIT'})
        
            # Verificar el estado de la respuesta
            if response.status_code == 200:
                return render(request, 'ConsultaEstadoC.html', {'content': response.text})
            else:
                return render(request, 'ConsultaEstadoC.html', {'content':  response.text})
        
    except Exception as e:
        return HttpResponse('Error: {}'.format(str(e)), status=500)
    

def mostrarTodos(request):
    try:
        if request.method == 'GET':
            response = requests.get(f'{API}/mostrarTodos')
            if response.status_code == 200:
                return render(request, 'ConsultaEstadoC.html', {'content2': response.text})
            else:
                return render(request, 'ConsultaEstadoC.html', {'content2': response.text})

    except Exception as e:
        return HttpResponse('Error: {}'.format(str(e)), status=500)
    

def misgraficas(request):
    try:
        if request.method == 'GET':
            
            mes = request.GET['mes'].upper()
            print(mes)
            

            response = requests.get(f'{API}/misgraficas/{mes}')
            print(response)

            bancos = []
            fecha = []
            monto = []

            if response.status_code == 200:
                data = response.json()

                for mes, info in data.items():
                    print("entro")
                    bancos.append(info['banco'])
                    fecha.append(mes)
                    monto.append(info['monto'])
                    print(bancos)
                    print(monto)
                    print(fecha)
                    
                context = {
                    'bancos': bancos,
                    'monto': monto,
                    'fecha': fecha
                }
                    
                return render(request, 'graficar.html', context)
            elif response.status_code == 400:
                return render(request, 'graficar.html', {'content': response.text})
        
    except Exception as e:
        print(e)
        return HttpResponse('Error: {}'.format(str(e)), status=500)