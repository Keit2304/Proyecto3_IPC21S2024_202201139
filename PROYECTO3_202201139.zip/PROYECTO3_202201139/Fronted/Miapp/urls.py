from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('cargarArchivo/', views.cargarArchivo, name='cargarArchivo'),
    path('cargarArchivo2/', views.cargarArchivo2, name='cargarArchivo2'),
    path('ConsultaEstadoC/', views.ConsultaEstadoC, name='ConsultaEstadoC'),
    path('ayuda/', views.ayuda, name='ayuda'),
    path('cargarArchivoXML/', views.cargarArchivoXML, name='cargarArchivoXML'),
    path('cargarArchivoXMLConfig/', views.cargarArchivoXMLConfig, name='cargarArchivoXMLConfig'),
    path('limpiarDatosConfig/', views.limpiarDatosConfig, name='limpiarDatosConfig'),
    path('limpiarDatosTransacciones/', views.limpiarDatosTransacciones, name='limpiarDatosTransacciones'),
    path('consultarEstadoCliente/', views.consultarEstadoCliente, name='consultarEstadoCliente'),
    path('mostrarTodos/', views.mostrarTodos, name='mostrarTodos'),
    path('graficar/', views.graficar, name='graficar'),
    path('misgraficas/', views.misgraficas, name='misgraficas'),
]